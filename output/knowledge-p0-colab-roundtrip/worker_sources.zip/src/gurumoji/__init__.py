"""Gurumoji application package."""
