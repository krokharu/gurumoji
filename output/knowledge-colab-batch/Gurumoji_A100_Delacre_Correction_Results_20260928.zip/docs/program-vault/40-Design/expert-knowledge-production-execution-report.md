# 専門家知識制作・実行報告書

更新日: 2026-09-28
状態: 作業継続中。配布可能な知識パックは未完成。

## 概要

17専門家向けの知識・プロンプトを、安全に作成・評価・配布するための実装基盤を整備した。契約、ジョブ管理、候補生成、パック検証、評価記録、オフライン Colab worker のコードは追加された。一方、権利確認、専門家ごとの知識作成、実データを用いた評価、Drive 経由の入出力、Colab での本番実行、配布承認は未完了である。現時点で利用者へ配布できる完成パックはない。

## 進捗

| 段階 | 状態 | 根拠・残作業 |
| --- | --- | --- |
| P0 現状調査 | 一部完了 | 再計測で17専門家・76文献ノート・108参照、未解決参照0を確認。権利経路未確認または審査pendingは95/108件。LM Studio API到達、RTX 5070は12,227 MiB中1,574 MiB空き、モデル一覧5件。5ケース分類はrubricと4/5一致したが自動判断には未承認。別枠のA100 80B合成probeは40GB A100・4K contextで成功。P0 roundtripの実行・返却成果物の受理は未完了。 |
| P1 データ契約・ジョブ管理 | 基盤実装、監修済み | Source / Claim / Job / Commit / Evaluation / Pack の閉じた契約、ハッシュ、世代、期限、受理済みコミットの一意性を実装。Sol のレビューで重大な未解決点なし。 |
| P2 権利・参照監査 | 一部完了 | 108参照を監査。CC BY論文6件に対する13件の利用記録は local / 指定 Colab / export を許可、remote LLM は不可。残り95参照は利用経路が未確定または要審査。本文取得や引用範囲の確認も残る。 |
| P3 知識・パック・読込基盤 | 一部完了 | 候補生成、Pack builder、runtime reader、評価記録の基盤を実装。Gale の登録済み抜粋から作成した1候補を Sol が支持したが、出典抜粋を含む人手確認待ちであり、内部候補のまま。承認済みパックではない。 |
| P4 Colab worker・再開 | オフライン基盤まで | ZIP の検証、期限・世代管理、部分結果拒否、オフライン worker を実装。Drive との実 transport、Colab ランタイム上での実ジョブ、再起動をまたぐ復旧は未確認。 |
| P5 論文取込 | 一部実装 | 許可済み Software Vault 参照とローカル資料の取込基盤を実装。個人 PDF の抽出・ページ位置確認・利用者別 overlay を含む end-to-end 経路は未完成。 |
| P6 専門家別の拡張・評価 | 未着手 | 既存データを超える14専門家分の知識作成、および17専門家すべての実データ評価は未完了。 |
| P7 配布 | 未着手 | ReleaseApproval、配布 ZIP、配布先での読込確認は未作成。 |

## AI と計算資源の担当

| AI / 資源 | 実施内容 | 使用量の記録 |
| --- | --- | --- |
| Codex Luna | 実装と作業進行を担当。契約、worker、評価・読込基盤、候補生成の改善を実施。 | Codex のトークン量はこの実行環境から取得できないため数値化していない。 |
| Codex Sol | P1 契約の監修、および候補と根拠の独立レビュー。 | トークン量は取得できないため数値化していない。 |
| ローカル Qwen3-8B / RTX 5070 | JSON 分類スモークと候補作成。 | usage を返した9呼出しの小計: 合計 20,994 tokens、計測時間 470.157秒。prompt / completion の総内訳は手元の集計に残っていない。usage のない失敗・timeout は含まない。 |
| Colab A100 | 80Bモデルの架空入力スモークを別Notebookで1回実行。専門家知識Jobは未実行。 | NVIDIA A100-SXM4-40GBでQwen3-Next-80B Q4_K_M、30 GPU layers、4K context。モデルhash一致、JSON/evidence ID適合。推論4.53秒、119 tokens、peak VRAM 28,956 MiB。全体35分26秒にはビルド・モデル取得を含み、GPU計算時間とはみなさない。 |

Qwen の呼出しは、完全な usage 記録が残る9件の合計である。今回の追加probeは5つの合成障害を一要求で分類し、正答基準との一致は4/5、計測時間は13.1秒だった。送信前にDNSが失敗したケースを`manual_review`と判定した保守的な誤分類があり、例外分類だけで再試行を決める運用には使えない。失敗したschema応答やtimeoutの計算量は分からないため、総利用量とは扱わない。Codex Luna / Sol についてもトークン量を推定していない。

## Colab と定期実行の状態

2026-09-27 05:13 UTC の Google Drive 再確認では、共有フォルダーに接続テストNotebook、P0 roundtrip bundle、P0 A100 Notebookの3件がある。P0 Notebookは同じDrive file ID上で65,145 bytes・SHA-256 `e8894b2f0ca0a7ec58dff4c9a3a879b7c2aa86165b3cf43614b46d412c35e0bf`。raw readbackはローカルの全byteと一致した。Notebookは60分ごとにRuntime/GPU・ジョブ候補を確認し、A100が割り当てられていれば軽量な256x256 FP16健全性確認を実行する。80分ごとに成果物のfile ID・size・SHA-256を照合し、同じ監視JSONへ履歴を保存する。Driveの更新時刻はNotebook資材の更新時刻でありColab実行の証拠ではない。P0 bundleは27,358 bytes。再接続後も結果ZIPと監視JSONは見つからず、Run all後の実行は未確認。この環境からDrive一覧は読めるが、Colabランタイムを直接起動・操作するAPIはない。

実ジョブがある間はA100を候補生成・バッチ評価などに優先使用し、最大55分単位でcheckpointを保存する。キューが空の間も60分ごとにジョブ候補とRuntime/GPU状態を点検し、A100が割り当てられていれば256x256 FP16行列積の軽量な健全性確認を1回実行して同じ監視JSONをDrive上で更新する。この確認は文献処理ではない。80分ごとにbundle・結果ZIPの存在、file ID、size、SHA-256を再照合する。不一致時は受理を止め、最後に確認したgenerationから再開する。P0 Notebookはジョブ候補の検出までで、本番文献処理用のmodel adapterは未実装。再実行時は同一job/generationの監視履歴を引き継ぐ。

Colab FAQはPro+で計算単位残高が十分な場合の連続コード実行を最大24時間と案内する一方、利用枠・idle timeout・GPU割当は変動し、早期終了もあり得る。したがって監視セルは最大24時間で終了し、接続維持は保証しない。常時稼働が必要なら専用VM/Colab Enterprise等を検討する。[Google Colab FAQ](https://research.google.com/colaboratory/faq.html)

**Colabでの開始操作は利用者が必要。** 共有Notebookを開いて両コードセルを順に実行し、Driveアクセスを承認すると、P0結果ZIPを直接保存してから定期監視を開始する。現時点では再接続後のA100実行と結果保存は未確認。

### P0 合成A100往復確認

`output/knowledge-p0-colab-roundtrip/` に世代1の合成Jobとローカル単一writer stateを作り、結果を受理する `scripts/accept_p0_colab_roundtrip.py` を追加した。Driveには次の2点をアップロードし、raw downloadのbyte sizeとSHA-256がローカル原本と一致することを確認した。

- [A100確認・定期監視Notebook](https://drive.google.com/file/d/1sN8Qwgt9uZ6liRB_tIc-aWEBydY1x16S/view?usp=drivesdk): 65,145 bytes、SHA-256 `e8894b2f0ca0a7ec58dff4c9a3a879b7c2aa86165b3cf43614b46d412c35e0bf`
- [合成roundtrip bundle](https://drive.google.com/file/d/1WkhBlBxrIKZVMEwQk_Gcm7vTVS0upHWw/view?usp=drivesdk): 27,358 bytes、SHA-256 `ad4041cee5600623ac5e9ca5a6855b3b9653266266e6de429d8626773c7c0415`

bundleは合成Source、1件のJob/request、承認Source registry、worker sourceだけで構成する。Colab Notebookは512×512 CUDA演算でA100を確認し、決定論的なsynthetic generatorで未承認結果ZIPを返す。LLM推論も実文献処理も行わないP0 transport smokeである。ローカルの隔離preflight結果を複製stateへ受け入れ、2 Artifact、generation 1の採用、同一ZIP再送の冪等性を確認した。本番側stateは`accepted_generation=0`を保っている。Notebookの実行・DriveへのNotebook保存・実A100出力の取得・`accept_p0_colab_roundtrip.py`による本番stateへの一度だけの受理は待機中。Job期限は2026-10-04 02:08 UTC。

## 検証記録と制約

- 以前の作業で worker / transport を含む focused tests 63件と回帰確認36件が成功した記録がある。今回の更新ではテストを再実行していない。
- 対象モジュールの `py_compile` と `git diff --check` は以前の実装確認で成功。今回の報告書・計画変更については別途差分確認が必要。
- Gale の1候補は出典全体に対する自動承認ではない。人手の出典確認と登録判断が済むまで候補状態を保つ。
- 現在の実装はオフライン worker と ZIP transport を含む基盤であり、Drive upload/download、Colab 実行、17専門家の評価、リリース承認を通した end-to-end の実績はない。

## 次に進める作業

1. Colab UI で接続テスト Notebook を実行・保存し、A100 の割当と再接続後の Drive 保存を確認する。
2. Gale 候補の出典抜粋を人が確認し、承認または棄却を記録する。
3. 利用経路が確認できた資料だけを対象に、候補を小さいバッチで A100 に処理させる。各バッチの結果を検証してから次の世代へ進む。
4. Drive transport と Colab worker の実運用 round-trip を確認後、専門家別の評価 suite と ReleaseApproval を完成させる。

### 2026-09-27 Local Papers overlay検証境界の更新

- P1/P5実装に、Base-only公開loader、Baseを実際に読んだ後だけoverlayを合成するloader、installation/Base rootに結び付いたLocal Papers adoption recordを追加した。
- adoptionはClaim hash、別reviewer identity、引用Sourceのversion・原文hash・Source record hashに結び付く。reviewerによる独立採用、Source一項目の訂正、root変更で古い記録は通らない。`revoked` adoptionを含むPackは受け付けない。
- `render_agent_request()` はmodel payload全体からfile URI、Windows/POSIX/UNC/home-relative pathを検出し、その文字列を丸ごと伏せる。`local_uri`のlocator valueも常に伏せる。これによりSource title/license/Claim/query内へのローカルパス混入にも対処する。
- Solの再監修では、当初のloader・adoption・path漏えいの指摘と追加で見つかったfile URI、drive-relative、root-relative、tilde、引用符付きPOSIX pathを修正した。最終read-only再監修で残存ブロッカーなし。テスト実行はしていない。
- active overlay rootの失効管理と、ローカルPDFの実取込・検索・索引、実資料からのadoption承認UIは未実装。静的overlayを失効させるには、利用側のpinned rootも切り替える必要がある。
- この報告時点でColab notebookはA100の小規模health probeを毎時1回実行し、Drive上のbundle/resultを80分ごとにID・size・SHA-256で再照合する。queueが空ならGPU probeのみで、論文処理ではない。本番job adapterが未実装のため、現段階ではqueued jobsは自動処理しない。

### 2026-09-27 follow-up verification

- Google DriveのNotebookをraw downloadで全byte再取得した。63,515 bytesとSHA-256 `8c60210dae43d0cd812ff64a31338f5c74fe186edff0df7ac6610ecdb06b9c0c`がローカルNotebookと一致した。
- 再取得した共有Driveフォルダーには、A100 Notebook、P0 bundle、接続確認Notebookだけがあり、結果ZIPと監視JSONはない。ユーザーのColab再接続後も、P0 runtime実行とDriveへの成果物保存は未確認である。
- knowledge-builder対象8ファイルのfocused suiteは76件成功。追加したreaderテストは引用符付き・colon-prefixed POSIX、absolute/drive-relative/root-relative Windows、UNC、tilde/home path、`file:` URIを確認し、HTTPS URLは保持する。
- この時点ではcandidate_pipeline単体suiteが未整備だった。下段の追加確認でfocused testsを加え、最終suiteは88件成功した。

### 2026-09-27 Colabスケジュール更新

- Sol監修で、Python文字列へのID直挿し、既存Drive resultのhash取り違え、LM Studioリクエストのproxy通過、`file:` locator漏れを指摘された。各項目をliteral化・永続hash pin・ProxyHandler無効化・file URI全形拒否で修正し、再監修で全指摘が閉じていることを確認した。

- Colab公式FAQの現行説明では、利用枠・idle timeout・GPU割当・VM最大寿命は変動し、実行継続を保証しない。Pro+でも十分なcompute unitsがある場合に連続実行は最大24時間まで。接続維持だけを目的にGPUを空回しする構成を避け、実処理があるときだけA100を使うスケジュールへ変更した。[Google Colab FAQ](https://research.google.com/colaboratory/faq.html)
- 共有Drive上の同じNotebook file IDを更新した。60分ごとのRuntime/GPU・ジョブ待ち行列確認と、A100割当時の軽量な256x256 FP16健全性確認、80分ごとのDrive bundle/result ID・size・SHA-256照合、同一監視JSONへの履歴保存・再開を行う。健全性確認は重いダミー処理ではない。Drive共有フォルダーを再確認したが、実行結果ZIPと監視JSONはまだなく、Colab上のRun allは未確認。
- 最終更新Notebookは63,012 bytes、SHA-256 `0fb5fc36801633cb97e9434b6a793ed890657da7143accaf4ab7bb2004304684`。Driveからraw bytesを取り直してsize/hash一致を確認。Drive更新時刻は2026-09-27 04:06:06 UTC、フォルダー再確認時刻は04:07 UTC。結果ZIPと監視JSONはまだなく、Colab上のRun allは未確認。P0でA100上に流せるのは現在の合成transport smokeのみ。本番モデルadapterがまだないため、承認済み文献からの知識生成ジョブはまだA100へ定期投入できない。
- 関連する10モジュールのfocused suiteは88件成功。candidate_pipelineはloopback/proxy無効化・local path拒否・source rights/provenanceを含む7件、Colab schedulerは文字列literal・Drive result hash pinを含む3件。Solの読み取り専用監修では重大/高リスク指摘なし。Notebook code cell 2件の構文確認、対象Python modulesの`py_compile`、metadata hash確認、`git diff --check`も成功。

### 2026-09-27 P2 SAGE rights audit

- `LIT-hermann-2024-fg-interaction-coding`の書誌情報にあったCrossref由来のCC BY 4.0表示を、SAGE公式記事ページのRights and permissions欄で確認した。記事ページはCC BY 4.0で任意の利用・複製・頒布を帰属表示付きで許可している。[SAGE article](https://journals.sagepub.com/doi/10.1177/16094069241286848)、[CC BY 4.0 legal code](https://creativecommons.org/licenses/by/4.0/legalcode.en)。
- 文献ノートにlicense ID/URL、LLM processing permission、route allowlist、審査根拠・日時を記録。local、利用者が起動するColab A100、言い換えた出典付きClaimのexportを許可し、remote LLMはプロジェクト方針で拒否。第三者コンテンツと本文・図表の配布は対象外。研究知識の抽出範囲はabstract-onlyのまま。
- `source-audit --all-experts`で17専門家・108参照・未解決0・status/correction status欠落0を再確認。レビュー済みは5 unique papers、12 expert-reference rows。権利未確認または審査pendingは100から96へ減少。

### 2026-09-27 IRSP rights audit

- `LIT-delacre-2017-welch`の掲載誌International Review of Social Psychology公式記事ページにCC BY 4.0表示があることを確認し、ライセンスURL・LLM permission・route allowlist・審査根拠を文献ノートへ記録した。[IRSP article](https://rips-irsp.com/articles/10.5334/irsp.82)、[CC BY 4.0 legal code](https://creativecommons.org/licenses/by/4.0/legalcode.en)。
- 同ページは訂正記事DOI `10.5334/irsp.661`への案内も掲載。権利metadataは原論文のみを対象とし、訂正記事の内容は取り込まず、訂正が関係するClaimは内容照合まで承認しない。
- 全体の権利監査は4 unique sources・11 expert-reference rowsがレビュー済み、97/108 rowsが未確認または審査pending。これは権利metadataの確認であり、知識Claimの内容承認数ではない。

### 2026-09-27 FQS rights audit

- `LIT-mayring-2000-qca`のForum Qualitative Social Research公式記事ページにCC BY 4.0表示があることを確認し、ライセンスURL・LLM permission・route allowlist・審査根拠をノートへ記録した。[FQS article](https://www.qualitative-research.net/index.php/fqs/article/view/1089)、[CC BY 4.0 legal code](https://creativecommons.org/licenses/by/4.0/legalcode.en)。
- `correction_status: not_checked`はそのまま維持。今回の権利確認は内容の妥当性や訂正履歴の確認を含まず、それらはClaim承認前に別途確認する。
- 最新監査は5 unique sources・12 expert-reference rowsがレビュー済み、96/108 rowsが未確認または審査pending。

### 2026-09-27 04:15 UTC Colab Drive status

- 共有フォルダーにはA100用P0 Notebook、合成roundtrip bundle、接続確認Notebookの3件があり、実行結果ZIPと監視JSONはまだなかった。
- 04:15時点でNotebookのRun allとA100実行は確認できていない。Colabランタイムをこの接続から直接起動・操作するAPIはない。

### 2026-09-27 04:54 UTC A100 hourly check update

- Drive上の既存Notebookは60分ごとの状態確認と80分ごとのDrive監査を持っていたが、実際のコードではA100演算は起動時の一度だけだった。60分ごとの確認でA100が割り当たっていれば、256x256 FP16行列積を1回実行し、成否を監視JSONに記録するよう修正した。重いダミー生成はしない。
- 同じDrive file ID `1sN8Qwgt9uZ6liRB_tIc-aWEBydY1x16S`を更新し、65,145 bytes・SHA-256 `e8894b2f0ca0a7ec58dff4c9a3a879b7c2aa86165b3cf43614b46d412c35e0bf`をraw readbackで照合した。
- フォルダー再確認ではNotebook、27,358-byte入力bundle、接続確認Notebookの3件のみで、結果ZIP・監視JSONはまだない。Colabの再接続は聞いているが、Run all後の出力は未確認。
- 本番モデルadapterが未実装のため、現段階でA100が行う実作業はP0合成transport smokeと毎時の軽量GPU健全性確認まで。実ジョブbundleは要手動確認として記録する。
- Colabは利用枠・idle timeout・VM寿命・GPU割当が変動するため、このループは接続維持を保証しない。1回の実行は最大24時間で停止する。[Google Colab FAQ](https://research.google.com/colaboratory/faq.html)

### 2026-09-27 Springer Nature rights audit

- `LIT-byrne-2022-reflexive-ta`のSpringer Nature公式記事ページはOpen AccessとCC BY 4.0を明記し、適切な帰属・ライセンスリンク・変更表示を条件に利用・共有・改変・配布を許可している。[Springer article](https://link.springer.com/article/10.1007/s11135-021-01182-y)、[CC BY 4.0 legal code](https://creativecommons.org/licenses/by/4.0/legalcode.en)。
- 文献ノートにライセンス、LLM処理許可、route allowlist、審査者・日時・根拠を記録した。abstract-scopeは維持し、本文内容の正確性や査読状態を承認した扱いにはしていない。第三者素材の別クレジットは個別確認が必要。
- `source-audit --all-experts`は17専門家・108参照・未解決0・status/correction欠落0を再確認。レビュー済みは6 unique papers・13 expert-reference rows、権利未確認または審査pendingは96から95へ減少。

### 2026-09-27 05:13 UTC Colab reconnect recheck

- ユーザーの再接続後に共有Driveを再確認したが、追加ファイルはなく、結果ZIPと監視JSONも見つからなかった。DriveのNotebook本体は65,145 bytes・SHA-256 `e8894b2f0ca0a7ec58dff4c9a3a879b7c2aa86165b3cf43614b46d412c35e0bf`で、raw readbackはローカル版と一致した。
- ランタイムの再接続だけではNotebookセルが実行された証跡にならない。Run allの実行・Drive認可・A100割当は未確認。Google Drive接続にはColabランタイムを直接操作するAPIがないため、Notebookを開いてRun allする操作が必要。
- 定期Notebookの仕様は60分ごとのRuntime/GPU確認と、A100割当時の軽量なGPU確認、80分ごとのDrive成果物照合。Colabが終了した場合は処理も止まるため、接続維持を保証しない。実文献のA100ジョブはmodel adapter未実装のためまだ投入されない。

### 2026-09-27 06:06 UTC Colab定期処理・P3境界更新

- ユーザー要望に合わせ、Drive上の既存Notebook ID `1sN8Qwgt9uZ6liRB_tIc-aWEBydY1x16S` を更新した。実行中は60分ごとにRuntime/GPU/queueを確認し、A100割当時は軽量256x256 FP16 health probeを行う。80分ごとにDrive artifactのID・size・SHA-256を検査し、同じmonitor JSONへ履歴を保存する。queueが空でも毎時の運用確認を続ける。
- 現行Notebookにproduction model adapterがないため、今はA100で専門家知識を生成していない。health probeはGPUの稼働状態を記録する軽量診断で、論文・ダミー知識の生成はしない。権利gateを通過した実jobをA100へ優先投入するadapterの実装は未完了。監視セルは最大24時間で自動終了する。[Google Colab FAQ](https://research.google.com/colaboratory/faq.html)では実行上限・idle timeout・GPU availabilityは変動し、Pro+の連続実行も十分なcompute unitsがある場合に最大24時間とされる。
- Drive Notebookの更新版は65,711 bytes、SHA-256 `5ef9b866381f1859035e148c81f0e2e6a6904cc1680c8c9b1319d935a1bb1ecb`。raw downloadでsizeとSHA-256をreadback照合した。共有folderにはNotebook、27,358-byte input bundle、接続確認Notebookの3件だけがあり、P0 result ZIPとmonitor JSONはまだない。Run all実行・Drive認可・A100割当は未確認。
- P3ではGale論文のページ4だけからローカルQwen3-8Bがpending候補を1件生成した。今回の成功呼出しは1,787 prompt + 86 completion = 1,873 tokens、1.213秒。ローカル集計は今回分を含め成功10呼出し、22,867 tokens、471.370秒。出力先guardを追加する前に失敗した1呼出しは実行量不明のため集計外。
- P3候補は未承認batch/review bundleとして保留中で、配布Packへは登録していない。Solのコードのみの監修で、Source文を配列・候補間に分割する経路と、推論中の出力先差替えを指摘された。候補全体の本文一致検査・上限付きshingle索引・書込直前の出力先再検証を追加し、最終レビューで高リスク問題なしを確認した。Solは文献・候補内容を読まず、テストも実行していない。こちらもsyntax compileと`git diff --check`のみ実施した。
- AI別作業量: 主担当Codex（Luna運用）はコード・Notebook・計画/報告の実装を担当。Sol（gpt-6-sol）は4回のコード限定レビューを実施したが、レビューtoken量はツールから取得できない。ローカルQwen3-8Bの今回の成功生成は1,873 tokens / 1.213秒。Colab Run allは未実行確認のため、この作業でのA100 GPU時間は未計測。

### 2026-09-27 06:14 UTC Colab 再接続後のDrive再確認

- 共有フォルダーを再確認し、更新済みのP0 A100 Notebook（65,711 bytes）、27,358-byte入力bundle、接続確認Notebookの3件を確認した。P0結果ZIPと監視JSONはまだ作られていない。
- したがって、ランタイムを再接続した状態は確認できても、更新済みNotebookの`Run all`、Drive認可、A100割当、毎時処理の開始は未確認。Colab操作APIはこの接続にないため、共有Notebookを開いて`Run all`し、Drive認可を完了する必要がある。
- Notebookの定期処理は空ジョブ時にA100割当を確認して軽量256x256 FP16健全性演算を1回行い、毎時の状態をDrive監視JSONへ記録する。80分ごとにbundle/resultのfile ID・size・SHA-256を再照合する。これは実文献処理ではなく、本番model adapterも未実装のため、実際の知識生成・評価にはまだA100を使っていない。

### 2026-09-27 07:28 UTC 定期監視とDrive反映の更新

- 既存Drive IDのNotebook `1sN8Qwgt9uZ6liRB_tIc-aWEBydY1x16S`とbundle `1WkhBlBxrIKZVMEwQk_Gcm7vTVS0upHWw`を更新した。Notebookは118,858 bytes / SHA-256 `eefa76fcef97c84766350962bf85432a0e9018841e4d5be1ab07263d57b233c0`、bundleは37,005 bytes / SHA-256 `7140aa4636c0bb1a680ca3d4b9e7b1e6b0f4aa7231c81192802f3c5ca8a62a7d`。Drive raw readbackで両ファイルのサイズと全byte SHA-256が一致した。
- [Colab A100 Notebook](https://drive.google.com/file/d/1sN8Qwgt9uZ6liRB_tIc-aWEBydY1x16S/view)は、5分ごとのJob確認、毎時の状態記録とA100 health probe、80分ごとのDrive artifact監査を設定した。本番JobはA100が割り当てられた場合のみ、Qwen3-32B-AWQ pinned revisionで1 excerptずつ実行する。Source registryはローカルに残し、返却成果はcandidateとして検証する。
- Drive監査はモデル実行と別threadで行う。前の監査が終わらない場合は次回監査を遅延記録し、Drive APIやmodel loadの長時間化でも各間隔がずれるbest-effort運用である。24時間は監視loopの上限であり、実行中threadを強制停止する上限ではない。Colabのidle timeout、VM lifetime、GPU割当はサービス側で変動し、常時接続を保証しない。[Google Colab FAQ](https://research.google.com/colaboratory/faq.html)
- 同一共有フォルダーにあるのはNotebook、bundle、接続確認Notebookの3点。monitor JSONとP0 result ZIPは見つからず、NotebookをRun allしたこと、A100推論、本番文献処理は未確認。Drive fileの接続状態だけではセル実行の証拠にならない。
- 実装はCodex Luna、Solの読み取り専用監査は3回。今回のローカルLLM・A100利用はなし。token量は各ツールから取得できないため未計測。syntax compileと`git diff --check`は通過、テストは実行していない。

### 2026-09-27 14:26 UTC A100 Qwen3-Next-80B 合成probe

- 最初のNotebookはA100の空きVRAMを70,000 MiB以上要求し、40GB A100を事前確認で終了した。これは容量不足の実測ではなく、80GB向けpreflight条件との不一致だった。
- 40GB用Notebookを使った再実行は `NVIDIA A100-SXM4-40GB` 上で成功した。Qwen公式 `Qwen3-Next-80B-A3B-Instruct-Q4_K_M.gguf` を固定revisionから取得しSHA-256を照合、llama.cppもcommit `9adc7f420c37641921b32e326b3d4a538256b878` に固定した。GPUへ30層を載せ、残りをhost RAM側で動かす構成だった。
- 実際のcontext設定は4,096 tokens、入力72 tokens、出力47 tokensであり、当初計画の8K入力試験ではない。架空の1要求に対してJSON schemaと `SYNTHETIC-1` のevidence IDは適合した。実文献の根拠支持・専門家知識の品質を測った結果ではない。
- run全体は2,126.06秒（35分26秒）。うちCUDA llama.cpp buildは936.08秒（15分36秒）、モデルdownloadは781.54秒（13分02秒）、model loadは141.08秒、推論は4.53秒だった。全体時間をGPU計算時間とは扱わない。usageは119 tokens。最大GPU memoryは28,956 MiB / 40,960 MiB、推論後の空きは11,486 MiB。
- [実測JSON](https://drive.google.com/file/d/1Tb3W0TGWWIvChN30qTqd_6R53IcRGOst/view)を共有Driveで確認した。これにより80Bモデルの部分GPU offload・ロード・短い合成生成までは通ったが、本番worker、Drive roundtrip、文献処理を実証したものではない。

### 2026-09-28 01:37 UTC A100 8K/16K context probe準備

- 4K実測を受け、`scripts/prepare_a100_80b_context_probe.py` と [8K/16K context probe Notebook](https://drive.google.com/file/d/11anbU7pIFYN3pvosIlwbyfrIl0KsPvAu/view) を作成・共有Driveへ追加した。Notebookは8,192 contextを先に、合格後のみ16,384 contextを試す。各段階で会話template込みのtokenizer計測を行い、contextの75%を使う架空入力、最大64出力tokens、1並列、30 GPU layers、VRAM・ロード・推論時間・schema/evidence IDを記録する。
- Drive metadataでNotebook名、21,725 bytes、保存先folderを照合した。Notebookは未実行で、A100実測結果はまだない。Colab runtimeをこの接続から起動するAPIはないため、利用者がNotebookを開き`Run all`する必要がある。新runtimeでは前回と同様にビルド・モデル取得時間も55分budgetへ含まれる。


### 2026-09-28 02:26 UTC A100 Delacre correction batch

- WSL??Colab CLI??A100 High-RAM??????????`NVIDIA A100-SXM4-80GB`???? `Qwen/Qwen3-32B-AWQ@0499c3ac83fdef8810b907a23894ba91e95eddd8` ????????????????????Colab???????????????????????Colab CLI???????????
- `LIT-delacre-2022-correction`????PDF?CC BY 4.0??????????Colab route???????????4???Yuen?????????????SDR????Student/Welch??????????????????????????2???????Excerpt?SHA-256??????
- 4???????????????????????????`accepted_unapproved_candidate_commit`???????????????????????Welch?Yuen??I??????SDR???????????????Student/Welch??????????????????????????????????
- ??????????????77.572??????????Transformers 4.57.6 / Tokenizers 0.22.2??????????4.51.3 / 0.21.4?????AWQ import????????????????????????????
- ?????Colab????????????????????????????????Knowledge Pack??????????????????????28??8/17???????????77??109??????0?Colab route???14?????95??????????
